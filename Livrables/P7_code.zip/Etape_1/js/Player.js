class Player {
    constructor(number, damage, x, y, src){
        this.number = number;
        this.damage = damage;
        this.x = x ;
        this.y = y;
        this.src = src;
        
    }
}

export { Player }