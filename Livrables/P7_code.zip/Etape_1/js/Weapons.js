class Weapon {
    constructor(name, damages, x, y, src) {
        this.name = name;
        this.damages = damages;
        this.x = x;
        this.y = y;
        this.src = src;
    }
}

export { Weapon }