class Weapon {
    constructor(name, damages, x, y) {
        this.name = name;
        this.damages = damages;
        this.x = x;
        this.y = y;
    }
}

export { Weapon }