class Weapon {
    constructor(name, damages, x, y, nameFR) {
        this.name = name;
        this.damages = damages;
        this.x = x;
        this.y = y;
        this.nameFR = nameFR;
    }
}

export { Weapon }